package com.backend.countryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
