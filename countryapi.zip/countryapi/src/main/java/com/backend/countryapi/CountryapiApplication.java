package com.backend.countryapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryapiApplication.class, args);
	}

}
